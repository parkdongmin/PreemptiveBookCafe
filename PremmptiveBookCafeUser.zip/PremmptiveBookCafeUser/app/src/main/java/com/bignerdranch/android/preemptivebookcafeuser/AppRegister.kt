package com.bignerdranch.android.preemptivebookcafeuser

import android.content.Context
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import com.bignerdranch.android.preemptivebookcafeuser.retrofit.JoinData
import com.bignerdranch.android.preemptivebookcafeuser.retrofit.JoinResponse
import com.bignerdranch.android.preemptivebookcafeuser.retrofit.RetrofitClient
import com.bignerdranch.android.preemptivebookcafeuser.retrofit.ServiceApi
import kotlinx.android.synthetic.main.app_register.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class AppRegister : AppCompatActivity() {

    private val service: ServiceApi? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.app_register)

        var service = RetrofitClient.getClient().create(ServiceApi::class.java)

        joinExBtn.setOnLongClickListener {
            attemptJoin()
        }

    }

    private fun attemptJoin() {
        val num: String = mainNumTextBox.text.toString()
        val email: String = mainEmailTextBox.text.toString()
        val password: String = mainPwTextBox.text.toString()


        startJoin(JoinData(num, password, email))
    }

    private fun startJoin(data: JoinData) {
        service!!.userJoin(data).enqueue(object : Callback<JoinResponse?>() {
            override fun onResponse(call: Call<JoinResponse?>?, response: Response<JoinResponse?>) {
                val result: JoinResponse? = response.body()
                Toast.makeText(this@AppRegister, result.getEmail(), Toast.LENGTH_SHORT).show()
                if (result.getClassNo() === 200) {
                    finish()
                }
            }

            override fun onFailure(call: Call<JoinResponse?>?, t: Throwable) {
                Toast.makeText(this@AppRegister, "회원가입 에러 발생", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val imm: InputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(currentFocus?.windowToken, 0)
        return true
    }
}