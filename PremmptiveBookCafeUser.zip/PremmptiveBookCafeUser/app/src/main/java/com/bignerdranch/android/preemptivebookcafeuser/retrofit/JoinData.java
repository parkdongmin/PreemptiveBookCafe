package com.bignerdranch.android.preemptivebookcafeuser.retrofit;

import com.google.gson.annotations.SerializedName;

public class JoinData {
    @SerializedName("classNo")
    private String classNo;

    @SerializedName("password")
    private String password;

    @SerializedName("email")
    private String email;

    public JoinData(String classNo, String password, String email) {
        this.classNo = classNo;
        this.password = password;
        this.email = email;
    }
}