package com.bignerdranch.android.preemptivebookcafeuser.retrofit;

import com.google.gson.annotations.SerializedName;

public class JoinResponse {
    @SerializedName("classNo")
    private int classNo;

    @SerializedName("email")
    private String email;

    public int getClassNo() {
        return classNo;
    }

    public String getEmail() {
        return email;
    }
}
