package com.bignerdranch.android.preemptivebookcafeuser.retrofit;

import com.google.gson.annotations.SerializedName;

public class LoginData {
    @SerializedName("classNo")
    String classNo;

    @SerializedName("password")
    String password;

    public LoginData(String userEmail, String userPwd) {
        this.classNo = classNo;
        this.password = password;
    }
}
